package com.example.lifecycle

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.i("MainActivity", "On Create")
        Toast.makeText(applicationContext,"On Create",Toast.LENGTH_SHORT).show()
    }
    //use log.i(tag , msg) , log.i , see output in logcat-> info.
    // log.i -> info , log.d-> debug , log.e-> error , log.w-> warn, log.v

    override fun onStart() {
        super.onStart()
        Toast.makeText(applicationContext,"On Start",Toast.LENGTH_SHORT).show()
        Log.i("MainActivity", "On Start") }

    override fun onPause() {
        super.onPause()
        Toast.makeText(applicationContext,"On Pause",Toast.LENGTH_SHORT).show()
        Log.i("MainActivity", "On Pause") }

    override fun onResume() {
        super.onResume()
        Toast.makeText(applicationContext,"On Resume",Toast.LENGTH_SHORT).show()
        Log.i("MainActivity", "On Resume") }

    override fun onStop() {
        super.onStop()
        Toast.makeText(applicationContext,"On Stop",Toast.LENGTH_SHORT).show()
        Log.i("MainActivity", "On Stop") }

    override fun onDestroy() {
        super.onDestroy()
        Toast.makeText(applicationContext,"On Destroy",Toast.LENGTH_SHORT).show()
        Log.i("MainActivity", "On Destroy") }
}